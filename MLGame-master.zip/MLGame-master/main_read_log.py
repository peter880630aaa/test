from games.arkanoid.log.read_log import print_log

if __name__ == "__main__":
    print_log()