import pickle
import os.path

def print_log():
    dir_path = os.path.dirname(__file__)
    file_path = os.path.join(dir_path, "ml_EASY_3_2020-03-13_18-34-31.pickle")

    with open(file_path, "rb") as f:
        p = pickle.load(f)
    
    print(p[2167])